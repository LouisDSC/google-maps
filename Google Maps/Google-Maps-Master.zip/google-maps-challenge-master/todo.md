# Plan Of Action

- Complete the styling for the marker info window DONE

- Open the info window marker on store selection in stores list DONE

- Allow a user to search for the stores in a zip code DONE

- Add a beautiful transition on the hover of an individual store DONE

**DONE**

